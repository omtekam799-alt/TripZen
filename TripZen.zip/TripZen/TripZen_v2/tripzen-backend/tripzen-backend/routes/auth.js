const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

// =====================================
// 🟢 REGISTER - POST /api/auth/register
// =====================================
router.post("/register", async (req, res) => {
  try {
    const { name, phone, email, password } = req.body;

    // Validation
    if (!name || !phone) {
      return res.status(400).json({ message: "Name aur Phone zaroori hai" });
    }

    // Check already exists
    const existingUser = await User.findOne({ phone });
    if (existingUser) {
      return res.status(400).json({ message: "Yeh phone number pehle se registered hai" });
    }

    // Hash password (if provided)
    let hashedPassword = undefined;
    if (password) {
      hashedPassword = await bcrypt.hash(password, 10);
    }

    // Create user
    const user = await User.create({
      name,
      phone,
      email,
      password: hashedPassword,
    });

    // Generate token
    const token = jwt.sign(
      { id: user._id, phone: user.phone, name: user.name, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.status(201).json({
      message: "Registration successful ✅",
      token,
      user: { id: user._id, name: user.name, phone: user.phone, role: user.role },
    });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 LOGIN - POST /api/auth/login
// =====================================
router.post("/login", async (req, res) => {
  try {
    const { phone, password } = req.body;

    if (!phone) {
      return res.status(400).json({ message: "Phone number daalo" });
    }

    const user = await User.findOne({ phone });

    if (!user) {
      return res.status(404).json({ message: "User nahi mila, pehle register karein" });
    }

    // Password check (if password set)
    if (user.password && password) {
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Password galat hai ❌" });
      }
    }

    // Generate token
    const token = jwt.sign(
      { id: user._id, phone: user.phone, name: user.name, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      message: "Login successful 🎉",
      token,
      user: { id: user._id, name: user.name, phone: user.phone, role: user.role },
    });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 OTP LOGIN (Firebase verify ke baad)
// POST /api/auth/otp-login
// =====================================
router.post("/otp-login", async (req, res) => {
  try {
    const { name, phone } = req.body;

    if (!phone) {
      return res.status(400).json({ message: "Phone number daalo" });
    }

    // Find or create user
    let user = await User.findOne({ phone });

    if (!user) {
      // New user - auto register
      user = await User.create({ name: name || "User", phone });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user._id, phone: user.phone, name: user.name, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      message: "OTP Login successful 🎉",
      token,
      user: { id: user._id, name: user.name, phone: user.phone, role: user.role },
    });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 GET PROFILE - GET /api/auth/profile
// =====================================
const { protect } = require("../middleware/auth");

router.get("/profile", protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    if (!user) return res.status(404).json({ message: "User nahi mila" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;

const express = require("express");
const router = express.Router();
const Booking = require("../models/Booking");
const { protect, adminOnly } = require("../middleware/auth");

// =====================================
// 🟢 CREATE BOOKING - POST /api/bookings
// (Login zaroori hai)
// =====================================
router.post("/", protect, async (req, res) => {
  try {
    const { packageId, packageName, price, from, to, travelDate } = req.body;

    const booking = await Booking.create({
      user: req.user.id,
      package: packageId || undefined,
      packageName: packageName || undefined,
      price: price || 0,
      from: from || undefined,
      to: to || undefined,
      travelDate: travelDate ? new Date(travelDate) : undefined,
      paymentStatus: "pending",
      status: "pending",
    });

    res.status(201).json({ message: "Booking save ho gayi ✅", booking });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 MY BOOKINGS - GET /api/bookings/my
// =====================================
router.get("/my", protect, async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user.id })
      .populate("package", "name destination days image")
      .sort({ createdAt: -1 });

    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🔒 ALL BOOKINGS (Admin) - GET /api/bookings
// =====================================
router.get("/", protect, adminOnly, async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("user", "name phone email")
      .populate("package", "name destination price")
      .sort({ createdAt: -1 });

    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 PAYMENT SUCCESS - PUT /api/bookings/:id/payment
// =====================================
router.put("/:id/payment", protect, async (req, res) => {
  try {
    const { razorpayPaymentId, razorpayOrderId } = req.body;

    const booking = await Booking.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      {
        paymentStatus: "paid",
        status: "confirmed",
        razorpayPaymentId,
        razorpayOrderId,
      },
      { new: true }
    );

    if (!booking) {
      return res.status(404).json({ message: "Booking nahi mili" });
    }

    res.json({ message: "Payment confirmed ✅", booking });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 CANCEL BOOKING - PUT /api/bookings/:id/cancel
// =====================================
router.put("/:id/cancel", protect, async (req, res) => {
  try {
    const booking = await Booking.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      { status: "cancelled" },
      { new: true }
    );

    if (!booking) {
      return res.status(404).json({ message: "Booking nahi mili" });
    }

    res.json({ message: "Booking cancel ho gayi", booking });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;

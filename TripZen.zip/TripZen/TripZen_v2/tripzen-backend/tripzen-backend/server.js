// ============================================
//  TripZen Backend - Main Server
//  Express + MongoDB + JWT Auth
// ============================================

require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

// =====================================
// MIDDLEWARE
// =====================================
app.use(express.json());
app.use(cors({
  origin: process.env.FRONTEND_URL || "*", // Set FRONTEND_URL in .env for production
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));

// =====================================
// MONGODB CONNECTION
// =====================================
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB Connected"))
  .catch(err => {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1);
  });

// =====================================
// ROUTES
// =====================================
app.use("/api/auth",     require("./routes/auth"));
app.use("/api/packages", require("./routes/packages"));
app.use("/api/bookings", require("./routes/bookings"));
app.use("/api/payment",  require("./routes/payment"));
app.use("/api/contact",  require("./routes/contact"));

// =====================================
// HOME ROUTE
// =====================================
app.get("/", (req, res) => {
  res.json({
    message: "🌍 TripZen Backend is running!",
    version: "2.0.0",
    routes: {
      auth:     "/api/auth",
      packages: "/api/packages",
      bookings: "/api/bookings",
      payment:  "/api/payment",
      contact:  "/api/contact",
    }
  });
});

// =====================================
// 404 HANDLER
// =====================================
app.use((req, res) => {
  res.status(404).json({ message: "Route not found ❌" });
});

// =====================================
// ERROR HANDLER
// =====================================
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Server error", error: err.message });
});

// =====================================
// START SERVER
// =====================================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running: http://localhost:${PORT}`);
});

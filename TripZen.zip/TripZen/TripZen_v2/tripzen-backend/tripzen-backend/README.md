# 🌍 TripZen Backend

TripZen Travel Agency ka complete backend - Express.js + MongoDB + JWT Authentication

---

## 📁 Folder Structure

```
tripzen-backend/
├── models/
│   ├── User.js        → User data (name, phone, role)
│   ├── Package.js     → Tour packages
│   ├── Booking.js     → User bookings
│   └── Contact.js     → Contact messages
├── routes/
│   ├── auth.js        → Register / Login / OTP Login
│   ├── packages.js    → Packages CRUD
│   ├── bookings.js    → Booking create / view
│   ├── payment.js     → Razorpay order + verify
│   └── contact.js     → Contact form
├── middleware/
│   └── auth.js        → JWT token check
├── .env               → Config (ye file share mat karna!)
├── server.js          → Main server
├── seed.js            → Sample data add karo
└── package.json
```

---

## 🚀 Setup (Pehli Baar)

### 1. Dependencies install karo
```bash
npm install
```

### 2. .env file update karo
```env
MONGO_URI=mongodb://localhost:27017/tripzen
JWT_SECRET=koi_bhi_random_string
PORT=5000
RAZORPAY_KEY_ID=rzp_test_XXXX
RAZORPAY_KEY_SECRET=XXXX
```

### 3. Sample packages add karo
```bash
node seed.js
```

### 4. Server chalao
```bash
# Normal
node server.js

# Auto-restart wala (development)
npm run dev
```

---

## 📡 API Endpoints

### 🔐 Auth Routes
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/auth/register` | Naya user register |
| POST | `/api/auth/login` | Phone + Password login |
| POST | `/api/auth/otp-login` | Firebase OTP ke baad login |
| GET | `/api/auth/profile` | Apni profile dekho 🔒 |

### 📦 Packages
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/packages` | Saare packages dekho |
| GET | `/api/packages/:id` | Ek package detail |
| POST | `/api/packages` | Package add karo 🔒 Admin |
| PUT | `/api/packages/:id` | Package update 🔒 Admin |
| DELETE | `/api/packages/:id` | Package delete 🔒 Admin |

### 📋 Bookings
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/bookings` | Booking karo 🔒 |
| GET | `/api/bookings/my` | Meri bookings 🔒 |
| GET | `/api/bookings` | Saari bookings 🔒 Admin |
| PUT | `/api/bookings/:id/payment` | Payment confirm 🔒 |
| PUT | `/api/bookings/:id/cancel` | Booking cancel 🔒 |

### 💳 Payment (Razorpay)
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/payment/create-order` | Razorpay order banao 🔒 |
| POST | `/api/payment/verify` | Payment verify karo 🔒 |

### 📞 Contact
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/contact` | Message bhejo |
| GET | `/api/contact` | Saare messages 🔒 Admin |

> 🔒 = Login (JWT token) zaroori hai

---

## 🌐 Frontend mein kaise use karein

### Step 1: OTP Login ke baad backend ko batao
```javascript
// login.html mein - Firebase OTP verify ke baad yeh add karo:

confirmationResult.confirm(code).then(async function() {
  let name = document.getElementById("name").value;
  let phone = document.getElementById("phone").value;

  // Backend ko OTP login batao
  let res = await fetch("http://localhost:5000/api/auth/otp-login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, phone })
  });

  let data = await res.json();

  // Token save karo
  localStorage.setItem("token", data.token);
  localStorage.setItem("userName", data.user.name);
  localStorage.setItem("userPhone", data.user.phone);

  window.location.href = "index.html";
});
```

### Step 2: Packages fetch karo
```javascript
// script.js ya packages.html mein:
async function loadPackages() {
  let res = await fetch("http://localhost:5000/api/packages");
  let packages = await res.json();
  // packages render karo...
}
```

### Step 3: Protected request karo (with token)
```javascript
let token = localStorage.getItem("token");

let res = await fetch("http://localhost:5000/api/bookings/my", {
  headers: {
    "Authorization": "Bearer " + token
  }
});
```

---

## 💡 Tips

- **MongoDB Atlas** use karo free mein: https://cloud.mongodb.com
- **Razorpay Test** mode mein fake payments test kar sakte ho
- Production mein `NODE_ENV=production` karo aur CORS mein apna domain daalo

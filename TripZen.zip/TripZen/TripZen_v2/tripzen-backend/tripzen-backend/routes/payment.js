const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const crypto = require("crypto");

// =====================================
// 🟢 CREATE RAZORPAY ORDER - POST /api/payment/create-order
// =====================================
router.post("/create-order", protect, async (req, res) => {
  try {
    const Razorpay = require("razorpay");

    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });

    const { amount, currency = "INR", packageName } = req.body;

    if (!amount) {
      return res.status(400).json({ message: "Amount daalo" });
    }

    const options = {
      amount: amount * 100, // Razorpay paise mein leta hai
      currency,
      receipt: `receipt_${Date.now()}`,
      notes: {
        packageName,
        userId: req.user.id,
      },
    };

    const order = await razorpay.orders.create(options);

    res.json({
      message: "Order created ✅",
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: process.env.RAZORPAY_KEY_ID, // Frontend ko chahiye
    });
  } catch (err) {
    res.status(500).json({ message: "Payment order create nahi hua", error: err.message });
  }
});


// =====================================
// 🟢 VERIFY PAYMENT - POST /api/payment/verify
// =====================================
router.post("/verify", protect, async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    // Signature verify karo
    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest("hex");

    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({ message: "Payment verify nahi hua ❌" });
    }

    res.json({
      message: "Payment verified ✅",
      paymentId: razorpay_payment_id,
      orderId: razorpay_order_id,
    });
  } catch (err) {
    res.status(500).json({ message: "Verification error", error: err.message });
  }
});

module.exports = router;

const jwt = require("jsonwebtoken");

// ✅ User Login Check
const protect = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1]; // Bearer <token>

  if (!token) {
    return res.status(401).json({ message: "Login karein pehle ❌" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { id, phone, name, role }
    next();
  } catch (err) {
    return res.status(401).json({ message: "Token invalid hai ❌" });
  }
};

// ✅ Admin Only Check
const adminOnly = (req, res, next) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ message: "Admin access chahiye ❌" });
  }
  next();
};

module.exports = { protect, adminOnly };

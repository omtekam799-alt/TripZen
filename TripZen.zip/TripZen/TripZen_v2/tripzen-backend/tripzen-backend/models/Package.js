const mongoose = require("mongoose");

const packageSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Package name is required"],
      trim: true,
    },
    destination: {
      type: String,
      required: true,
    },
    days: {
      type: String, // e.g. "3D/2N"
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    image: {
      type: String, // URL
      default: "",
    },
    description: {
      type: String,
      default: "",
    },
    includes: {
      type: [String], // ["Hotel", "Meals", "Sightseeing"]
      default: [],
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Package", packageSchema);

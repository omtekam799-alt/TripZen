const express = require("express");
const router = express.Router();
const Package = require("../models/Package");
const { protect, adminOnly } = require("../middleware/auth");

// =====================================
// 🟢 GET ALL PACKAGES - GET /api/packages
// =====================================
router.get("/", async (req, res) => {
  try {
    const packages = await Package.find({ isActive: true });
    res.json(packages);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🟢 GET SINGLE PACKAGE - GET /api/packages/:id
// =====================================
router.get("/:id", async (req, res) => {
  try {
    const pkg = await Package.findById(req.params.id);
    if (!pkg) return res.status(404).json({ message: "Package nahi mila" });
    res.json(pkg);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🔒 ADD PACKAGE (Admin only) - POST /api/packages
// =====================================
router.post("/", protect, adminOnly, async (req, res) => {
  try {
    const { name, destination, days, price, image, description, includes } = req.body;

    if (!name || !destination || !days || !price) {
      return res.status(400).json({ message: "Saari zaroori fields bhari jaayein" });
    }

    const pkg = await Package.create({ name, destination, days, price, image, description, includes });
    res.status(201).json({ message: "Package add ho gaya ✅", package: pkg });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🔒 UPDATE PACKAGE (Admin only) - PUT /api/packages/:id
// =====================================
router.put("/:id", protect, adminOnly, async (req, res) => {
  try {
    const pkg = await Package.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!pkg) return res.status(404).json({ message: "Package nahi mila" });
    res.json({ message: "Package update ho gaya ✅", package: pkg });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🔒 DELETE PACKAGE (Admin only) - DELETE /api/packages/:id
// =====================================
router.delete("/:id", protect, adminOnly, async (req, res) => {
  try {
    await Package.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ message: "Package delete ho gaya ✅" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;

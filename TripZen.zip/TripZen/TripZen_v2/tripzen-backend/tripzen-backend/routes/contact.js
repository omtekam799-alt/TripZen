const express = require("express");
const router = express.Router();
const Contact = require("../models/Contact");
const { protect, adminOnly } = require("../middleware/auth");

// =====================================
// 🟢 SUBMIT CONTACT - POST /api/contact
// =====================================
router.post("/", async (req, res) => {
  try {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ message: "Saari fields bhari jaayein" });
    }

    const contact = await Contact.create({ name, email, message });
    res.status(201).json({ message: "Message bhej diya gaya ✅", contact });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


// =====================================
// 🔒 GET ALL CONTACTS (Admin) - GET /api/contact
// =====================================
router.get("/", protect, adminOnly, async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 });
    res.json(contacts);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;

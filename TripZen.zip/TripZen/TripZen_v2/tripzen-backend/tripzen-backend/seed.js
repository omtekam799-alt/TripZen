// ============================================
// Seed Script - Sample Packages add karo DB mein
// Run: node seed.js
// ============================================

require("dotenv").config();
const mongoose = require("mongoose");
const Package = require("./models/Package");

const samplePackages = [
  {
    name: "Goa Tour",
    destination: "Goa",
    days: "3D/2N",
    price: 7999,
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
    description: "Goa ke sunhare beaches aur vibrant nightlife ka anand lo!",
    includes: ["Hotel", "Breakfast", "Beach activities", "Local sightseeing"],
  },
  {
    name: "Manali Trip",
    destination: "Manali",
    days: "5D/4N",
    price: 12999,
    image: "https://images.unsplash.com/photo-1605640840605-14ac1855827b",
    description: "Himalayan peaks aur snow valleys mein adventure!",
    includes: ["Hotel", "All meals", "Solang Valley trip", "Rohtang Pass visit"],
  },
  {
    name: "Kashmir Trip",
    destination: "Kashmir",
    days: "4D/3N",
    price: 14999,
    image: "https://images.unsplash.com/photo-1605540436563-5bca919ae766",
    description: "Dharti ka Jannat - Dal Lake aur Shikara ride!",
    includes: ["Houseboat stay", "All meals", "Shikara ride", "Mughal Garden visit"],
  },
  {
    name: "Bali Tour",
    destination: "Bali, Indonesia",
    days: "6D/5N",
    price: 49999,
    image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4",
    description: "Indonesia ka paradise - temples, beaches aur rice terraces!",
    includes: ["5-star hotel", "All meals", "Ubud tour", "Tanah Lot temple", "Beach club"],
  },
  {
    name: "Dubai Tour",
    destination: "Dubai, UAE",
    days: "5D/4N",
    price: 39999,
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c",
    description: "Future ka sheher - Burj Khalifa se lekar desert safari tak!",
    includes: ["4-star hotel", "Breakfast", "Burj Khalifa entry", "Desert Safari", "City tour"],
  },
  {
    name: "Thailand Tour",
    destination: "Bangkok & Pattaya",
    days: "5D/4N",
    price: 29999,
    image: "https://images.unsplash.com/photo-1528360983277-13d401cdc186",
    description: "Southeast Asia ka sabse popular destination!",
    includes: ["Hotel", "Breakfast", "Coral Island trip", "Safari World", "City tour"],
  },
];

async function seedDB() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ MongoDB Connected");

    await Package.deleteMany({}); // Purane data saaf karo
    await Package.insertMany(samplePackages);

    console.log(`✅ ${samplePackages.length} packages add ho gaye!`);
    process.exit(0);
  } catch (err) {
    console.error("❌ Seed failed:", err.message);
    process.exit(1);
  }
}

seedDB();
